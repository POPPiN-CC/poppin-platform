-- Fix for incorrect Cornell Tech pilot coordinates.
-- The previous seed placed these ~400m too far west, landing them in the East River
-- instead of on Roosevelt Island. Verified real anchor point for Cornell Tech:
-- 40.755811, -73.956296 (2 West Loop Rd). These five are spread across that real
-- campus footprint instead.

update pops set lat = 40.7558, lng = -73.9563 where name = 'Campus Plaza';
update pops set lat = 40.7554, lng = -73.9565 where name = 'Tech Walk';
update pops set lat = 40.7565, lng = -73.9558 where name = 'Campus Lawn';
update pops set lat = 40.7558, lng = -73.9550 where name = 'Waterfront Promenade';
update pops set lat = 40.7556, lng = -73.9570 where name = 'Bloomberg Cafe';
